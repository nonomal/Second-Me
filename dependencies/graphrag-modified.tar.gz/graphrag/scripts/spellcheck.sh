#!/bin/sh
npx --yes cspell -c cspell.config.yaml --no-progress lint .